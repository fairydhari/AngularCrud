import { Component, Input} from '@angular/core';
import { CompositeFilterDescriptor } from '@progress/kendo-data-query';
import { FilterService, BaseFilterCellComponent } from '@progress/kendo-angular-grid';

@Component({
  selector: 'app-status-filter',
  templateUrl: './status-filter.component.html',
  styleUrls: ['./status-filter.component.css']
})
export class StatusFilterComponent extends BaseFilterCellComponent {
  @Input() public filter: CompositeFilterDescriptor;
  @Input() public filterService: FilterService;
  @Input() public data: any[];  // Dropdown list data
  @Input() public textField: string;
  @Input() public valueField: string;
  @Input() public field: string;
  
  /*public get selectedValue(): any {
    const filter = this.filterByField(this.valueField);
    return filter ? filter.value : null;
}*/
/*
@Input() public filter: CompositeFilterDescriptor;
    @Input() public data: any[];
    @Input() public textField: string;
    @Input() public valueField: string;*/

  /*  public get defaultItem(): any {
        return {
            [this.textField]: "All",
            [this.valueField]: null
        };
    }
    constructor(filterService: FilterService) {
      super(filterService);
  }*/
  /*public onChange(value: any): void {
    console.log(value);
    console.log(this.valueField);
    console.log("filter"+this.filter);
    this.applyFilter(
        value === null ? // value of the default item
            this.removeFilter(this.valueField) : // remove the filter 
            this.updateFilter({ // add a filter for the field with the value
                field: this.valueField,
                operator:"eq",
                value: value
            })
    ); // update the root filter
    this.filterService.filter(this.filter);
}*/
public get selectedValue(): any {
  const filter: any = this.filterByField(this.field);
  return filter ? filter.value : undefined;
}

public get defaultItem(): any {
  return {
    [this.textField]: 'Select item...',
    [this.valueField]: undefined
  };
}
constructor(filterService: FilterService) {
  super(filterService);
}

public onChange(value: any): void {
  console.log( this.field);
  this.filter = this.updateFilter({
    field: "Status",
    operator: "eq",
    value: value
  });

  this.filterService.filter(this.filter);
}
/*
public categoryChange(values: any[], filterService: FilterService): void {
  filterService.filter({
      filters: values.map(value => ({
          field: "Status",
          operator: "eq",
          value
      })),
      logic: "or"
  });
}*/
}
