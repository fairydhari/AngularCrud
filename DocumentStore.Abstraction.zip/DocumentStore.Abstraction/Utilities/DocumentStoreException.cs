﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;

namespace DocumentStore.Abstraction
{
    [Serializable]
    public class DocumentStoreException: Exception
    {
        //TODO: Attach the item which caused execption
        public DocumentStoreException()
        {

        }

        public DocumentStoreException(string message)
            : base(message)
        {
        }

        public DocumentStoreException(string message, Exception innerException) 
            : base(message, innerException)
        {
        }

        protected DocumentStoreException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }

        // This method makes the constructor awaitable.
        public TaskAwaiter<DocumentStoreException> GetAwaiter()
        {
            throw this;
        }


        public override void GetObjectData(
        SerializationInfo info, StreamingContext context)
        {
            base.GetObjectData(info, context);
            info.AddValue("itemID", ""); //TODO: Set the Document ID
        }
    }
}
