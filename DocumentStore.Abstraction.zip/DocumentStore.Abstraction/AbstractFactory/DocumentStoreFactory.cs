﻿namespace DocumentStore.Abstraction
{
    public interface IDocumentStoreFactory
    {
        IDocumentStore GetDocumentStore();
    }
}
