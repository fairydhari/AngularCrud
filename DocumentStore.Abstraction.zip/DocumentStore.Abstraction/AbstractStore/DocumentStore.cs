﻿using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace DocumentStore.Abstraction
{
    public interface IDocumentStore
    {
 
        Task<Stream> GetDocumentStreamAsync(string itemId, string itemPath);

        Task<string> GetDocumentUrlAsync(string itemId, string itemPath);

        Task<string> GetDocumentUrlAsync(string itemId, string itemPath, int expiryMinutes);

        
        Task<byte[]> GetDocumentBytesAsync(string itemId, string itemPath);

        
        Task<bool> SaveDocumentAsync(string itemId, string itemPath, Stream stream, Dictionary<string, string> metadata);

        
        Task<bool> SaveDocumentAsync(string itemId, string itemPath, byte[] fileContent, Dictionary<string, string> metadata);


        Task<bool> ReplaceDocumentAsync(string itemId, string itemPath, Stream stream);

        Task<bool> ReplaceDocumentAsync(string itemId, string itemPath, byte[] fileContent);

        Task<bool> DeleteDocumentAsync(string itemId, string itemPath);
    }
}
