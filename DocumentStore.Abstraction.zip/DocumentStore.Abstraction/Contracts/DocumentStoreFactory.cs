﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;

namespace DocumentStore
{
    public class DocumentStoreFactory
    {
        /// <summary>
        /// Returns a Document Store w.r.t. the configuration
        /// </summary>
        public static IDocumentStore GetStore()
        {
            string store = ConfigurationManager.AppSettings["DOC_STORE"].ToString();
            switch(store)
            {
                case "LOCAL_DISK": return new LocalDiskDocumentStore();
                case "AZURE_BLOB": return new AzureBlobDocumentStorage();
                case "MOCK_STORE": return new MockStore();
            }
            throw new System.ArgumentOutOfRangeException();
        }
    }
}
