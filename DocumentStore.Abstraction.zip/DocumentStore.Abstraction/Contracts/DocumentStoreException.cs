﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Runtime.Serialization;
using System.Security.Permissions;
using System.Text;
using System.Threading.Tasks;

namespace DocumentStore.Contracts
{
    [Serializable]
    public class DocumentStoreException: Exception
    {
        //TODO: Attach the item which caused execption
        public DocumentStoreException()
        {

        }

        public DocumentStoreException(string message)
            : base(message)
        {
        }

        public DocumentStoreException(string message, Exception inner)
            : base(message, inner)
        {
        }
        // This method makes the constructor awaitable.
        public TaskAwaiter<DocumentStoreException> GetAwaiter()
        {
            throw this;
        }

        [SecurityPermission(SecurityAction.LinkDemand,
            Flags = SecurityPermissionFlag.SerializationFormatter)]
        public override void GetObjectData(
        SerializationInfo info, StreamingContext context)
        {
            base.GetObjectData(info, context);
            info.AddValue("itemID", ""); //TODO: Set the Document ID
        }
    }
}
