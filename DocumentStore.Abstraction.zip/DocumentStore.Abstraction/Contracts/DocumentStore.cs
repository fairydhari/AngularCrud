﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocumentStore
{
    public interface IDocumentStore
    {
        /// <summary>
        /// Returns the stream with the file content
        /// </summary>
        /// <param name="itemID">Unique Identifier to select the file</param>
        /// <param name="itemPath">Path/Folder/Container info if needed</param>
        Task<Stream> GetDocument(string itemId, string itemPath);

        Task<string> GetDocumentUrlAsync(string itemId, string itemPath, int expiryMinutes = 0);

        /// <summary>
        /// Returns the file byte size and the content as byte array
        /// </summary>
        /// <param name="itemID">Unique Identifier to select the file</param>
        /// <param name="itemPath">Path/Folder/Container info if needed</param>
        Task<byte[]> GetDocumentContent(string itemId, string itemPath);

        /// <summary>
        /// Saves the Document in the provided stream corresponds to the id
        /// </summary>
        /// <param name="itemID">Unique Identifier to select the file</param>
        /// <param name="itemPath">Path/Folder/Container info if needed</param>
        /// <param name="stream">Data</param>
        /// <returns>True if saving complete. Throws DocumentStoreException otherwise </returns>
        Task<bool> SaveDocument(string itemId, string itemPath, Stream stream, Dictionary<string, string> metadata);

        /// <summary>
        /// Saves the Document in the provided bytes corresponds to the id
        /// </summary>
        /// <param name="itemID">Unique Identifier to select the file</param>
        /// <param name="itemPath">Path/Folder/Container to save file</param>
        /// <param name="fileBytes">Data</param>
        /// <returns>True if saving complete. Throws DocumentStoreException otherwise </returns>
        Task<bool> SaveDocument(string itemId, string itemPath, byte[] fileBytes, Dictionary<string, string> metadata);
    }
}
