﻿using DocumentStore.Contracts;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Auth;
using Microsoft.WindowsAzure.Storage.Blob;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocumentStore
{
    public class AzureBlobDocumentStorage : IDocumentStore
    {
        private const string constantErrorMessage = " For more details check inner exception.";
        private int expiryHours;

        public AzureBlobDocumentStorage()
        {
            expiryHours = Int32.Parse(System.Configuration.ConfigurationManager.AppSettings["SASExpiryHours"].ToString());
        }

        public AzureBlobDocumentStorage(int _expiryHours)
        {
            expiryHours = _expiryHours;
        }

        private async Task<CloudBlobContainer> GetAzureStorageContainer(string blobContainer)
        {
            try
            {
                string accountName = System.Configuration.ConfigurationManager.AppSettings["AzureStorageAccountName"];
                string accountKey = System.Configuration.ConfigurationManager.AppSettings["AzureStorageAccountKey"];

                // Retrieve storage account from connection string.
                StorageCredentials creds = new StorageCredentials(accountName, accountKey);
                CloudStorageAccount storageAccount = new CloudStorageAccount(creds, useHttps: true);

                // Create the blob client.
                CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();

                // Retrieve a reference to a container.
                CloudBlobContainer container = blobClient.GetContainerReference(blobContainer);

                // Create the container if it doesn't already exist.
                await container.CreateIfNotExistsAsync();

                // Setting access type to  the container.
                //var permissions = container.GetPermissions();
                //permissions.PublicAccess = BlobContainerPublicAccessType.Container;
                //container.SetPermissions(permissions);

                return container;
            }
            catch (Exception ex)
            {
                throw new DocumentStoreException("GetAzureStorageContainer(" + blobContainer + ") failed while reading blobcontainer from Azure Blob Storage." + constantErrorMessage, ex);
            }
        }

        public async Task<Stream> GetDocument(string itemID, string itemPath)
        {
            var container = await GetAzureStorageContainer(ParseContainer(itemPath));
            try
            {
                CloudBlockBlob blob = (CloudBlockBlob)container.ListBlobs(ParseBlobName(itemID, itemPath), false).First();
                Stream stream = new MemoryStream();
                blob.DownloadToStream(stream);
                stream.Position = 0;
                return stream;
            }
            catch (Exception ex)
            {
                throw new DocumentStoreException("GetDocument(" + itemID + ") failed while reading as stream from Azure Blob Storage." + constantErrorMessage, ex);
            }
        }

        public async Task<byte[]> GetDocumentContent(string itemID, string itemPath)
        {
            var container = await GetAzureStorageContainer(ParseContainer(itemPath));
            try
            {
                CloudBlockBlob blob = (CloudBlockBlob)container.ListBlobs(ParseBlobName(itemID, itemPath), false).First();
                blob.FetchAttributes();
                byte[] fileContent = new byte[blob.Properties.Length];
                blob.DownloadToByteArray(fileContent, 0);
                return fileContent;
            }
            catch (Exception ex)
            {
                throw new DocumentStoreException("GetDocumentContent(" + itemID + ") failed while reading as byte array from Azure Blob Storage." + constantErrorMessage, ex);
            }
        }

        public async Task<string> GetDocumentUrlAsync(string itemId, string itemPath, int expiryMinutes = 0)
        {
            try
            {
                var container = await GetAzureStorageContainer(ParseContainer(itemPath));

                CloudBlockBlob blockBlob = container.GetBlockBlobReference(ParseBlobName(itemId,itemPath));

                //Create an ad-hoc Shared Access Policy with read permissions which will expire based on expiryHours
                SharedAccessBlobPolicy policy = new SharedAccessBlobPolicy()
                {
                    Permissions = SharedAccessBlobPermissions.Read,
                    SharedAccessExpiryTime = DateTime.UtcNow.AddMinutes(expiryMinutes > 0 ? expiryMinutes : expiryHours * 60),
                };

                blockBlob.FetchAttributes();
                //Set content-disposition header for force download
                SharedAccessBlobHeaders headers = new SharedAccessBlobHeaders()
                {
                    ContentDisposition = string.Format("file;attachment;filename=\"{0}\"", blockBlob.Metadata["filename"]),
                    ContentType = blockBlob.Metadata["filetype"],
                };
                var sasToken = blockBlob.GetSharedAccessSignature(policy, headers);
                return blockBlob.Uri.AbsoluteUri + sasToken;
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }
        
        private string ParseContainer(string itemPath)
        {
            return itemPath.Split('/')[0];
        }
        private string ParseBlobName(string itemId, string itemPath)
        {
            var parts = itemPath.Split('/').ToList();

            if (parts.Count() <= 1) return itemId;
            
            parts.Add(itemId);

            return String.Join("/", parts.ToArray(), 1, parts.Count()-1);     
        }

        public async Task<bool> SaveDocument(string itemId, string itemPath, Stream stream, Dictionary<string, string> metadata)
        {
            var container = await GetAzureStorageContainer(ParseContainer(itemPath));
            try
            {
                CloudBlockBlob blockBlob = container.GetBlockBlobReference(ParseBlobName(itemId, itemPath));

                await blockBlob.UploadFromStreamAsync(stream);

                return await SaveMetadataAsync(blockBlob, metadata);
            }
            catch (Exception ex)
            {
                throw new DocumentStoreException("SaveDocument(" + itemId + ") failed while writing the stream to Azure Blob Storage." + constantErrorMessage, ex);
            }
        }

        public async Task<bool> SaveDocument(string itemId, string itemPath, byte[] fileBytes, Dictionary<string, string> metadata)
        {
            var container = await GetAzureStorageContainer(ParseContainer(itemPath));
            try
            {
                CloudBlockBlob blockBlob = container.GetBlockBlobReference(ParseBlobName(itemId, itemPath));
                await blockBlob.UploadFromByteArrayAsync(fileBytes, 0, fileBytes.Length);
                
                return await SaveMetadataAsync(blockBlob, metadata);
            }
            catch (Exception ex)
            {
                throw new DocumentStoreException("SaveDocument(" + itemId + ") failed while writing byte array to Azure Blob Storage." + constantErrorMessage, ex);
            }
        }

        private async Task<bool> SaveMetadataAsync(CloudBlockBlob blob, Dictionary<string, string> metadata)
        {
            List<string> failed = new List<string>();
            foreach (var item in metadata)
            {
                try
                {
                    blob.Metadata.Add(item);
                }
                catch (Exception ex)
                {
                    failed.Add(item.Key + "=" + item.Value + "[" + ex.Message + "]");
                }
            }

            await blob.SetMetadataAsync();

            if (failed.Count > 0) throw new Exception(String.Join(", ", failed.ToArray()));

            return true;
        }

        private async Task<string> GetSharedAccessSignatureToken(string itemID, string itemPath)
        {
            var container = await GetAzureStorageContainer(ParseContainer(itemPath));
            try
            {
                CloudBlockBlob blockBlob = container.GetBlockBlobReference(ParseBlobName(itemID, itemPath));

                //Create an ad-hoc Shared Access Policy with read permissions which will expire based on expiryHours
                SharedAccessBlobPolicy policy = new SharedAccessBlobPolicy()
                {
                    Permissions = SharedAccessBlobPermissions.Read,
                    SharedAccessExpiryTime = DateTime.UtcNow.AddHours(expiryHours),
                };

                //Set content-disposition header for force download
                SharedAccessBlobHeaders headers = new SharedAccessBlobHeaders()
                {
                    ContentDisposition = string.Format("attachment;filename=\"{0}\"", itemID),
                };
                var sasToken = blockBlob.GetSharedAccessSignature(policy, headers);
                return blockBlob.Uri.AbsoluteUri + sasToken;
            }
            catch (Exception ex)
            {
                throw new DocumentStoreException("GetSharedAccessSignatureToken(" + itemID + ") failed while reading access token from Azure Blob Storage." + constantErrorMessage, ex);
            }
        }
    }
}
