﻿using DocumentStore.Contracts;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DocumentStore
{
    public class MockStore : IDocumentStore
    {
        private Dictionary<string, Stream> _files = new Dictionary<string, Stream>();
        private Dictionary<string, string> _paths = new Dictionary<string, string>();

        public async Task<Stream> GetDocument(string itemId, string itemPath)
        {
            var result = await Task.Run(() =>
            {
                Stream stream = _files[itemId];
                int size = (int)stream.Length;

                return stream;
            });
            return result;
        }


        public async Task<byte[]> GetDocumentContent(string itemId, string itemPath)
        {
            Stream stream = _files[itemId];
            int size = (int)stream.Length;

            byte[] fileBytes = new Byte[size];

            int ret = await stream.ReadAsync(fileBytes, 0, size);

            return fileBytes;
        }

        public async Task<string> GetDocumentUrlAsync(string itemId, string itemPath, int expiryMinutes)
        {
            try
            {
                return await Task<string>.Run(() =>
                {
                    return string.Empty;
                });
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }

        public async Task<bool> SaveDocument(string itemId, string itemPath, Stream stream, Dictionary<string, string> metadata)
        {
            var result = await Task.Run(() =>
            {
                _paths.Add(itemId, itemPath);
                _files.Add(itemId, stream);

                return true;
            });
            return result;
        }

        public async Task<bool> SaveDocument(string itemId, string itemPath, byte[] fileBytes, Dictionary<string, string> metadata)
        {
            throw await new DocumentStoreException("SaveDocument failed!",
                new NotImplementedException("MockStore doesn't implement SaveDocument method!"));
        }
    }
}
