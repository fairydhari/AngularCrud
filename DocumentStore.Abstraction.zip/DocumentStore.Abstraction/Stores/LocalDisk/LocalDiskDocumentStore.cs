﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace DocumentStore
{
    public class LocalDiskDocumentStore : IDocumentStore
    {
        string _filePath = AppDomain.CurrentDomain.BaseDirectory + ConfigurationManager.AppSettings["LocalStorageFolderPath"];
                    
        #region IDocumentStore Implementation

        public async Task<Stream> GetDocument(string itemId, string itemPath)
        {
           var result = await Task.Run(() =>
            {
                FileStream fs = new FileStream(ConstructFilePath(itemId, itemPath), FileMode.Open, FileAccess.Read);
                return fs;
            });
            return result;
        }

        public async Task<byte[]> GetDocumentContent(string itemId, string itemPath)
        {
            using (FileStream stream = (FileStream)await GetDocument(itemId, itemId))
            {
                byte[] fileBytes = new byte[stream.Length];
                object state = new { itemId = itemId, time = DateTime.Now };
                var tcs = new TaskCompletionSource<int>();
                stream.BeginRead(fileBytes, 0, fileBytes.Length, ar =>
                {
                    try
                    {
                        tcs.SetResult(stream.EndRead(ar));
                    }
                    catch (Exception exc)
                    {
                        tcs.SetException(exc);
                    }
                }, state);

                stream.Close();
                await tcs.Task;
                return fileBytes;
            }
        }

        public async Task<string> GetDocumentUrlAsync(string itemId, string itemPath, int expiryMinutes)
        {
            try
            {
                return await Task<string>.Run(() =>
                {
                    return string.Empty;
                });
            }
            catch (Exception)
            {
                return string.Empty;
            }
        }

        public async Task<bool> SaveDocument(string itemId, string itemPath, Stream stream, Dictionary<string, string> metadata)
        {
            var result = await Task.Run(() =>
            {
                string path = ConstructFilePath(itemId, itemPath);
                FileStream fileStream = new FileStream(path, FileMode.Create, FileAccess.ReadWrite);
                stream.CopyTo(fileStream);
                fileStream.Close();

                return true;
            });
            return result;
        }

        public async Task<bool> SaveDocument(string itemId, string itemPath, byte[] fileBytes, Dictionary<string, string> metadata)
        {
            string path = ConstructFilePath(itemId, itemPath);
            FileStream fileStream = new FileStream(path, FileMode.Create, FileAccess.ReadWrite);
            await fileStream.WriteAsync(fileBytes, 0, fileBytes.Length);
            fileStream.Close();

            return true;
        }
        
        #endregion IDocumentStore Implementation

        private string ConstructFilePath(string itemId, string itemPath)
        {
            var _fileDirectory = string.Join("/", new[] { _filePath, itemPath });
            if (!Directory.Exists(_fileDirectory)) Directory.CreateDirectory(_fileDirectory);
            return string.Join("/", new[] { _fileDirectory, itemId }); 
        }
    }
}
