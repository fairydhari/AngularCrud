import { TestBed, inject } from '@angular/core/testing';

import { HelpcontentService } from './helpcontent.service';

describe('HelpcontentService', () => {
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [HelpcontentService]
    });
  });

  it('should be created', inject([HelpcontentService], (service: HelpcontentService) => {
    expect(service).toBeTruthy();
  }));
});
