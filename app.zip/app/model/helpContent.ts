 export class HelpContent {
   ContentId: number;
   PermissionId: number;
   DescriptionAr: string;
   DescriptionEn: string;
   ContentImage: string;
    }
