import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { ContentListComponent } from './content-list/content-list.component';
import { HelpcontentService } from './services/helpcontent.service';
import { GridModule } from '@progress/kendo-angular-grid';
import { DomSanitizer, SafeResourceUrl, SafeUrl } from '@angular/platform-browser';
import { DialogModule } from '@progress/kendo-angular-dialog';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';


@NgModule({
  declarations: [
    AppComponent,
    ContentListComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    GridModule,
    DialogModule,
    BrowserAnimationsModule
    
  ],
  providers: [HelpcontentService],
  bootstrap: [AppComponent]
})
export class AppModule { }
