import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GridEgComponent } from './grid-eg.component';

describe('GridEgComponent', () => {
  let component: GridEgComponent;
  let fixture: ComponentFixture<GridEgComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GridEgComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GridEgComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
