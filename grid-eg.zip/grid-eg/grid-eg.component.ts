import { Component, OnInit } from '@angular/core';
import { process, State } from '@progress/kendo-data-query';
import { sampleProducts } from './products';
import { customers } from './customers';

import { IntlService } from '@progress/kendo-angular-intl';
import { Pipe, PipeTransform } from '@angular/core';
import { DatePipe } from '@angular/common';

import {
  GridComponent,
  GridDataResult,
  DataStateChangeEvent,
  FilterService
} from '@progress/kendo-angular-grid';

/*const distinct = data => data
    .map(x => x.Status)
    .filter((x, idx, xs) => xs.findIndex(y => y.Status === x.Status) === idx);*/

@Component({
  selector: 'app-grid-eg',
  templateUrl: './grid-eg.component.html',
  styleUrls: ['./grid-eg.component.css']
})
export class GridEgComponent implements OnInit {
 /* public state: State = {
    skip: 0,
    take: 10,

    // Initial filter descriptor
    /*filter: {
      logic: 'and',
      filters: []
    }*/
/*};*/
public state = {
  skip: 0,
  take: 10
  /*filter: {
    filters: [],
    logic: 'and'
  }*/
}
//public gridData: GridDataResult = process(sampleProducts, this.state);
/*public gridData: GridDataResult = process(customers, this.state);
public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.gridData1 = process(customers, this.state);
   // this.gridData = process(sampleProducts, this.state);
}*/
public listItems: Array<{ text: string, value: string }> = [
  { text: "Open", value: "O" },
  { text: "New", value: "N" },
  { text: "Close", value: "C" }
];
public gridData1: any[];
/*public gridData1 = [];
public dataStateChange(state) {
  this.state = state;
  this.gridData1 = process(customers, this.state);
}*/
  constructor(public datepipe: DatePipe) {
    
    //this.gridData1 = process(customers, this.state);
   }
 /* public mappedData: any[] =customers.map(item => {
item.CreatedDate = new Date(item.CreatedDate);
return item;
});*/
  ngOnInit() {
   /* this.service.subscribe().map((res)=>{
      res.map(product => {
            product.SomeDate= new Date(product.SomeDate)
            return product
          }) 
      return res
      })*/
     /* customers=>{customers.CreatedDate=new Date(customers.CreatedDate)};*/
    //  var datePipe = new DatePipe("en-US");  
    /*  customers.forEach(proj => {  
        console.log("dt" + proj.CreatedDate);
       // var dateOut = new Date(proj.CreatedDate);
       //proj.CreatedDate =new Date(proj.CreatedDate);;
        /////proj.CreatedDate =this.datepipe.transform(proj.CreatedDate, 'dd/MMM/yyyy');
         //   console.log("dt1" + proj.CreatedDate);
        
    }); */
     
    this.gridData1 = customers;
  
  }
  
 /*
  formatDate(myStringDate) {
    return new Date(parseInt(myStringDate.substr(6)));
}*/
/*
public categoryChange(values: any[], filterService: FilterService): void {
  filterService.filter({
      filters: values.map(value => ({
          field: "Status",
          operator: "eq",
          value
      })),
      logic: "or"
  });
}*/

}
